#include <iostream>
#include <string>
#include <vector>
#include <windows.h>
#include "Dataframe.h"

using namespace std;

int main() {
	System::Console::Beep();
	SetConsoleDisplayMode(GetStdHandle(STD_OUTPUT_HANDLE), CONSOLE_FULLSCREEN_MODE, 0);

	Dataframe *df;
	df = new Dataframe();
	df->cargar("dataset.csv");
	df->imprimir();

	system("pause");
	return 0;
}