#pragma once
#include "DataFrameUtil.h"

class Dataframe {
private:
	vector<DF::Lista*> datos;
public:
	Dataframe() {}
	void cargar(string dir) {
		DF::Lista *aux;
		int n = 0;
		ifstream archivo;
		string registro, dato;
		archivo.open(dir);
		if (!archivo.fail()) {
			while (getline(archivo, registro)) {
				stringstream ss(registro); n++;
				aux = new DF::Lista(n);
				datos.push_back(aux);
				while (getline(ss, dato, ',')) {
					aux->insertar(dato);
				}
			}
			cout << "El dataframe fue cargado de " << dir << endl;
		}
		archivo.close();
	}
	void imprimir() {
		for (int i = 0; i < datos.size(); ++i) {
			cout << datos.at(i)->getKey() << " | ";
			datos.at(i)->imprimir();
			cout << endl;
		}
	}
	~Dataframe() {}
};