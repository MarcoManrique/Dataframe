#pragma once
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

#define max_char 10

using std::cin;
using std::endl;
using std::cout;
using std::string;
using std::vector;
using std::getline;
using std::ifstream;
using std::ofstream;
using std::stringstream;
using System::String;

namespace DF {
	//
	class Nodo {
	private:
		Nodo *siguiente;
		string dato;
	public:
		Nodo(string dato) {
			siguiente = nullptr;
			this->dato = dato;
			this->dato.resize(max_char);
		}
		void setSiguiente(Nodo *siguiente) {
			this->siguiente = siguiente;
		}
		Nodo *getSiguiente() {
			return siguiente;
		}
		string getDato() {
			return dato;
		}
		~Nodo() {}
	};
	//
	class Lista {
	private:
		Nodo *inicio;
		Nodo *final;
		
		Lista *left;
		Lista *right;

		int nro;
		string key;
	public:
		Lista(int k) {
			inicio = nullptr;
			final = nullptr;
			left = nullptr;
			right = nullptr;
			nro = 0;
			key = std::to_string(k);
			key.resize(5);
		}
		void insertar(string dato) {
			Nodo *aux;
			aux = new Nodo(dato);
			if (inicio == nullptr) {
				inicio = aux;
			}
			else {
				final->setSiguiente(aux);
			}
			final = aux;
			++nro;
		}
		void imprimir() {
			if (inicio != nullptr) {
				Nodo *aux = inicio;
				while (aux != nullptr) {
					cout << aux->getDato() << " | ";
					aux = aux->getSiguiente();
				}
			}
		}
		string getKey(){
			return key;
		}
		~Lista() {}
	};
	//
	class Arbol {

	};
}