#pragma once
#include <iostream>
using namespace std;

namespace DF {
	class ListaNodo {
	private:
		ListaNodo *siguiente;
		int fila; //key

		//Datos
		char sexo;
		int id;
		int edad;
	public:
		ListaNodo(char sexo, int id, int edad) {
			siguiente == nullptr;
			this->sexo = sexo;
			this->id = id;
			this->edad = edad;
		}
		void setFila(int f) { fila = f; }
		void setSiguiente(ListaNodo *s) { siguiente = s; }

		char getsexo() { return sexo; }
		int getid() { return id; }
		int getedad() { return edad; }

		int getFila() { return fila; }
		ListaNodo *getSiguiente() { return siguiente; }
	};
	class Lista {
	private:
		ListaNodo *inicio;
		ListaNodo *final;
		int numero;
	public:
		Lista() {
			inicio = nullptr;
			final = nullptr;
			numero = 0;
		}
		void insertar(ListaNodo *aux) {
			if (inicio == nullptr) {
				inicio = aux;
				final = aux;
				++numero;
			}
			else {
				final->setSiguiente(aux);
				final = aux;
				++numero;
			}
			aux->setFila(numero);
		}
		void imprimir() {
			ListaNodo *aux;
			aux = inicio;
			cout << " A | B | C  | D  |" << endl;
			for (int i = 0; i < numero; ++i) {
				cout << " "<< aux->getFila() << "   ";
				cout << aux->getsexo() << "   ";
				cout << aux->getid() << "   ";
				cout << aux->getedad() << " ";
				cout << endl;
				aux = aux->getSiguiente();
			}
		}
		int getNumero() { return numero; }
		~Lista() {

		}
	};
	class BHeap {
	private:
		int *arr;
		int max; // 
		int size; //Heap Size
	public:
		int parent(int i) { return(i - 1) / 2; }
		int left(int i) { return(2 * i + 1); }
		int right(int i) { return(2 * i + 2); }
		BHeap(int max) {
			this->max = max;
			arr = new int[max];
			size = 0;
		}
		void insertar(int K) {
			if (size == max) return;
			int i = size;
			size++;
			arr[i] = K;
			while (i != 0 && arr[parent(i)] > arr[i]) { // Cambiar arr[parent(i)] < arr[i]
				swap(arr[i], arr[parent(i)]);
				i = parent(i);
			}
		}
		int extractMin() {
			if (size == 0) { return -1; }
			if (size == 1) { --size; return arr[0]; }
			int root = arr[0];
			arr[0] = arr[size - 1];
			--size;
			Heapify(0);
			return root;
		}
		void HeapSort() {
			int data = extractMin();
			cout << "HeapSort: ";
			while (data != -1) {
				cout << data << " ";
				data = extractMin();
			}
		}
		void Heapify(int i) {
			int l = left(i);
			int r = right(i);
			int small = i;
			if (l < size && arr[l] < arr[i]) { // CAMBIAR arr[l] > arr[i])
				small = l;
			}
			if (r < size && arr[r] < arr[small]) { // CAMBIAR arr[r] > arr[small]
				small = r;
			}
			if (small != i) {
				swap(arr[i], arr[small]);
				Heapify(small);
			}
		}
	};
}