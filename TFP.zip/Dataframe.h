#pragma once
#include <fstream>
#include <sstream>
#include <string>
#include "DataFrameUtil.h"

class Dataframe {
private:
	DF::Lista *list;
	int x;
public:
	Dataframe() {
		list = new DF::Lista();
	}
	void dibujar() {
		System::Console::Clear();
		list->imprimir();
	}
	void importar() {
		ifstream archivo;
		string registro;
		string tsexo, tid, tedad;
		char sexo;
		int id;
		int edad;
		archivo.open("dataset.csv");
		while (getline(archivo, registro)) {
			stringstream ss(registro);
			getline(ss, tsexo, ',');
			getline(ss, tid, ',');
			getline(ss, tedad, ',');
			sexo = tsexo[0];
			id = stoi(tid);
			edad = stoi(tedad);
			DF::ListaNodo *aux;
			aux = new DF::ListaNodo(sexo, id, edad);
			list->insertar(aux);
		}
		archivo.close();
	}
	void exportar() {

	}
	void ordenar(char columna) {

	}
};