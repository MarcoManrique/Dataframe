#include <iostream>
#include "Dataframe.h"
using namespace std;

int main() {
	// Implementaci�n 2
	Dataframe *df;
	df = new Dataframe();
	df->importar();
	df->ordenar('C');
	df->dibujar();

	system("pause>NULL");
	return 0;
}